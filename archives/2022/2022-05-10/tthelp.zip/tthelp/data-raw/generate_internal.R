## code to prepare `generate_internal` dataset goes here
#generate data

baby_names_all <- tidytuesdayR::tt_load(2022, week = 12)

baby_names <- baby_names_all$babynames


#save data
usethis::use_data(baby_names, internal = TRUE)
