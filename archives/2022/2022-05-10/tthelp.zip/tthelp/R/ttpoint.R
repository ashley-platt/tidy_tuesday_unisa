#' ttpoint
#'
#' Easily produce a scatter plot for two variables of interest
#' @param df data frame of interest
#' @param xvar variable for the x axis
#' @param yvar variable for the y axis
#' @param colour colour of data points
#' @param title title for scatter plot
#' @param x_title title for x axis
#' @param y_title title for y axis
#' @return scatter plot
#' @examples
#' plot1 <- ttscatter(df, xvar = "time", yvar = "sales", colour = "blue", title = "Sales per year");
#' @export


ttpoint <- function(df, xvar = "x", yvar = "y", colour = "colour", title = "title", x_title = "x_title", y_title = "y_title"){
  plot <- ggplot(df, aes_string(x = xvar, y = yvar)) +
                   geom_point(color = colour) +
    ggtitle(title) +
    xlab(x_title) +
    ylab(y_title)

  return(plot)
  }

