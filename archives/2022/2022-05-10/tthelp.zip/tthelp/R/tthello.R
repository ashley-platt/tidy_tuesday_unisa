#' tthello
#'
#' Say hello
#' @return hello, world!
#' @examples
#' tthello();
#' @export

tthello <- function() {
  print("Hello, world!")
}
