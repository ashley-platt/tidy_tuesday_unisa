#' ttread
#'
#' Read in, split up and provide a summary of the df
#' @param year year of chosen Tidy Tuesday data set
#' @param wk week of chosen Tidy Tuesday data set
#' @return data frame with all data set information and summary of variables
#' @examples
#' df1 <- ttread(2022, 2);
#' df2 <- ttread(2021, 13);
#' @export
ttread <- function(year, wk){
  df <- tidytuesdayR::tt_load(year, week = wk)

  all <-as.data.frame(do.call(cbind, df))

  df_all <<- all

  summary(df_all)
}
