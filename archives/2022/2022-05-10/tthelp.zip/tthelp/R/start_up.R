.onAttach <- function(libname, pkgname) {
  message <- c("\n Thank you for using the {tthelp} R package!",
               "\n \n This package was created to help with Tidy Tuesday Analysis.",
               "\n \n Happy coding! - AP")
  packageStartupMessage(message)
}
