#' ttgeom
#'
#' Produce a geom of any type
#' @param df data frame of interest
#' @param type type of geom
#' @param xvar variable for the x axis
#' @param yvar variable for the y axis
#' @param colour colour of data points
#' @param title title for scatter plot
#' @param x_title title for x axis
#' @param y_title title for y axis
#' @return scatter plot
#' @examples
#' plot1 <- ttgeom(df, type = geom_point, xvar = "time", yvar = "sales", colour = "blue", title = "Sales per year");
#' @export


ttgeom <- function(df, type = "geomtype", xvar = "x", yvar = "y", colour = "colour", title = "title", x_title = "x_title", y_title = "y_title"){
  plot <- ggplot(df, aes_string(x = xvar, y = yvar)) +
    type(color = colour) +
    ggtitle(title) +
    xlab(x_title) +
    ylab(y_title)

  return(plot)
}
