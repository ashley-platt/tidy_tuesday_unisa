#' ttwhich
#'
#' Graph suggestions based on variable types
#' @param xvar type of x variable
#' @param yvar type of y variable
#' @return graph suggstions
#' @examples
#' ttwhich(xvar = "cont", yvar = "disc");
#' @export

ttwhich <- function(xvar = "xtype", yvar = "ytype"){

  x <- xvar
  y <- yvar

  if(x == "cont" & y == "disc"){
    cat("use a coloumn, boxplot or violin graph")
  } else if(x == "disc" & y == "cont"){cat("use a column, boxplot or violin graph")} else if(x == "cont" & y == "cont"){cat("use a point or smooth graph")} else if( x == "cont" & y == "NA"){cat("use a freqpoly or histogram")} else if(x == "disc" & y == "NA"){cat("use a bar graph")} else {cat("oops something went wrong, try again")}

}
